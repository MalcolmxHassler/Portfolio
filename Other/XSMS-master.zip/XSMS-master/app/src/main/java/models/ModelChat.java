package models;

public class ModelChat {
}
