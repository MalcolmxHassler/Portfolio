package com.example.xsms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class apparence_num extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apparence_num);
    }
}
