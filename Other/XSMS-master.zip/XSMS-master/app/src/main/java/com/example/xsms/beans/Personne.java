package com.example.xsms.beans;

public class Personne {

}
